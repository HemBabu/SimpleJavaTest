package com.Model;

public class BulkRegistration {
}
