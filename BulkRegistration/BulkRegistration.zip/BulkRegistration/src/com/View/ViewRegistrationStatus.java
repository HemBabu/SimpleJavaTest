package com.View;

public class ViewRegistrationStatus {

}
